from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login ,logout

# from django.contrib.auth.models import User
from .models import Users, Offer, Product

# Create your views here.

def login_page(request):
    print(request.user)
    users = Users.objects.filter().all()
    m = {}
    for u in users:
        m[str(u.id)] = u.name
        print(u.name,u.id)
    context = {'users':m}
    return render(request,'login.html',context)


def user(request):
    if request.method == 'GET':
        user_id = request.GET.get('id')
        data = Users.objects.filter(id=user_id).first()
        if data.product_1==1:
            return HttpResponse('Offer already availed!')
        data2 = Product.objects.filter(id=1).first()
        context = {'user':user_id}
        return render(request, 'user.html', context)
    redirect('/')

def process(request):
    if request.method == 'GET':
        user_id = request.GET.get('id')
        data = Users.objects.filter(id=user_id).first()
        product_id = request.GET.get('prod_id')
        data2 = Product.objects.filter(id=product_id).first()
        if data2.stock==0:
            return HttpResponse(f'Item {data2.product_name} out of stock.')
        data2.stock -= 1
        data2.save()
        data.product_1 = 1
        data.save()
        return redirect(f'/user?id={user_id}')
    return redirect('/')
