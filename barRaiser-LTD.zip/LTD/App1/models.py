from django.db import models

# Create your models here.

class Users(models.Model):
    name = models.CharField(max_length=200, default=None)
    details = models.CharField(max_length=200, default=None)
    product_1 = models.SmallIntegerField(default=0)

    class Meta:
        db_table = 'users'

class Product(models.Model):
    product_name = models.CharField(max_length=100, default=None)
    details = models.CharField(max_length=200)
    stock = models.IntegerField(default=0)

    class Meta:
        db_table = 'product'

class Offer(models.Model):
    offer_name = models.CharField(max_length=100, default=None)
    product_id = models.IntegerField()
    details = models.CharField(max_length=200)
    start_ts = models.DateTimeField(null=True)
    expiry_mins = models.IntegerField(default=0)

    class Meta:
        db_table = 'offer'